<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Je suis Karim Bouzgarne, je suis développeur web sur Valence. J'ai réalisé ce portfolio dans le but de vous présenter mes compétences ainsi que mes expériences.">
    <meta name="author" content="Karim Bouzgarne">
    <meta name="keywords" content="karim bouzgarne, Portfolio, Portfolio Karim Bouzgarne, Karim Bouzgarne portfolio, développeur web, portfolio développeur web, karim bouzgarne développeur web, développeur web, développeur web lyon, développeur web Vienne, Portfolio développeur web Lyon, Webmaster, developpeur web Valence, portfolio développeur web Valence, Lyon">
    <meta name="title" content="Karim Bouzgarne - portfolio développeur web">
    <meta name="google-site-verification" content="pUwFNxm2JjysNVo9HCYya9qJmZuNOLrg27exQeuvyEw" />
    <meta name="msvalidate.01" content="0CDDB72BD03BFBC314AE8C9073B7461C" />

    <title title="Karim Bouzgarne">Karim Bouzgarne - Porfolio Développeur Web</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/animate.css">
    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Favicon -->

    <!-- <link rel="apple-touch-icon" sizes="57x57" href="img/favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="img/favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="img/favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="img/favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="img/favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="img/favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="img/favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="img/favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="img/favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="img/favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <link rel="manifest" href="img/favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff"> -->

    <link rel="apple-touch-icon" sizes="57x57" href="img/favicon/favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="img/favicon/favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="img/favicon/favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="img/favicon/favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="img/favicon/favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="img/favicon/favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="img/favicon/favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="img/favicon/favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="img/favicon/favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="img/favicon/favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon/favicon-16x16.png">
    <link rel="manifest" href="img/favicon/favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="img/favicon/favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">

    <!-- Custom styles for this template -->
    <link href="css/agency.min.css" rel="stylesheet">
    <link href="css/creative.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <link rel="icon" type="img/favicon" href="tonlien" />
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-127147520-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'UA-127147520-1');
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
    <style type="text/css">
      .list-unstyled{ 
        color: #f05f40!important;  
      }
      .fa-size {
        font-size: 30px;
      }
      .font-f {
            font-family: 'Open Sans','Helvetica Neue',Arial,sans-serif;    
      }
    </style>

  </head>

  <header>
    <div id="preloader">
      <div id="status">
        <h1 class="ml5">
          <span class="text-wrapper">
            <span class="line line1"></span>
            <span class="letters letters-left">K</span>
            <span class="letters letters-right">B</span>
            <span class="line line2"></span>
          </span>
        </h1>
      </div>
    </div>
  </header>

  <body id="page-top">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="#page-top" title="karim bouzgarne">KARIM BOUZGARNE</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">            
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#services">Services</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#portfolio">Portfolio</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#formation">Formation</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#contact">Contact</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <header id="masthead" class="masthead text-center text-white d-flex">
      <div class="container my-auto">
        <div class="row">
          <div class="col-lg-10 mx-auto">
            <div id="typed-strings">
              <h1 title="développeur web">Vous cherchez un développeur web ?</h1>
            </div>
            <h1 class="text-uppercase">
              <strong id="typed"></strong>
            </h1>
            <hr>
          </div>
          <div class="col-lg-8 mx-auto">
            <div id="typed-strings2">
              <p class="text-faded mb-5">Ça tombe bien ! Je suis passionné par le web et j'ai pu acquérir un certain nombre de compétences depuis mes débuts dans le web il y a déjà 6 ans de cela.<br>La suite c'est à vous de découvrir !</p>
            </div>            
            <p class="text-faded mb-5"><span id="typed2"></span></p>
            <div data-aos="fade-down" data-aos-delay="3000">           
              <i class="fas fa-arrow-circle-down text-primary fa-4x"></i>
            </div>            
          </div>
        </div>
      </div>
    </header>

    <section class="bg-primary" id="about">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 mx-auto text-center">
            <div data-aos="fade-right">
              <h2 class="section-heading text-white">Faisons connaissance :)</h2>            
              <hr class="light my-4">
            </div>
            <p class="text-faded mb-4">Avant toute chose, je me présente. J'ai 24 ans et je suis actuellement en poste de Webmaster / Développeur web à Valence. Je vous présente mon portfolio qui retrace mon parcour professionnel avec plus de précision.<br><br>J'ai sû me spécialiser au fil de mes formations et de mes expériences, dans le domaine du développement web.<br>C'est pourquoi je vous invite à consulter un panel non exhaustif de mes compétences.</p>
            <a class="btn btn-light btn-xl js-scroll-trigger" href="#services">Continuer</a>
          </div>
        </div>
      </div>
    </section>

    <section id="services">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center" data-aos="fade-right">
            <h2 class="section-heading">A votre service !</h2>
            <hr class="my-4">
          </div>
        </div>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-lg-3 col-md-6 text-center">
            <div class="service-box mt-5 mx-auto">
              <i class="fas fa-4x fa-gem text-primary mb-3 sr-icon-1"></i>
              <h3 class="mb-3">Frameworks</h3>
              <p class="text-muted mb-0">A l'aise avec les frameworks suivants ( Symfony 4, Angular 4, Ionic 3 ...)</p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 text-center">
            <div class="service-box mt-5 mx-auto">
              <i class="fas fa-4x far fa-eye text-primary mb-3 sr-icon-2"></i>
              <h3 class="mb-3">Veille techno</h3>
              <p class="text-muted mb-0">Toujours à l'affût des nouvelles technologies.</p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 text-center">
            <div class="service-box mt-5 mx-auto">
              <i class="fas fa-4x fa-users text-primary mb-3 sr-icon-3"></i>
              <h3 class="mb-3">Ergonomie</h3>
              <p class="text-muted mb-0">Soucieux de l'expérience utilisateur.</p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 text-center">
            <div class="service-box mt-5 mx-auto">
              <i class="fas fa-4x fa-heart text-primary mb-3 sr-icon-4"></i>
              <h3 class="mb-3">Passion</h3>
              <p class="text-muted mb-0">Beaucoup de coeur à l'ouvrage pour chaques projets.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="p-0" id="portfolio">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center" data-aos="fade-right">
            <h2 class="section-heading text-uppercase" title="Portfolio">Portfolio</h2>
            <h3 class="section-subheading text-muted">Présentation de mes dernières expériences.</h3>
          </div>
        </div>
        <div class="row">

          <div class="col-md-4 col-sm-6 portfolio-item" data-aos="zoom-in-down">
            <a class="portfolio-link" data-toggle="modal" href="#portfolioModalCM">
              <div class="portfolio-hover">
                <div class="portfolio-hover-content">
                  <i class="fas fa-plus fa-3x"></i>
                </div>
              </div>
              <img class="img-fluid" src="img/portfolio/des-mots-pour-voir.jpg" alt="Des mots pour voir">
            </a>
            <div class="portfolio-caption">
              <h4>Des mots pour voir</h4>
              <p class="text-muted">Portfolio (HTML5/CSS3, Bootstrap, PHP, JS, JQuery)</p>
            </div>
          </div>

          <div class="col-md-4 col-sm-6 portfolio-item" data-aos="zoom-in-down">
            <a class="portfolio-link" data-toggle="modal" href="#portfolioModalFP">
              <div class="portfolio-hover">
                <div class="portfolio-hover-content">
                  <i class="fas fa-plus fa-3x"></i>
                </div>
              </div>
              <img class="img-fluid" src="img/portfolio/flora-perre.jpg" alt="Flora Perre">
            </a>
            <div class="portfolio-caption">
              <h4>Flora Perre</h4>
              <p class="text-muted">Portfolio (HTML5/CSS3,Angular JS, Bootstrap, PHP, JS, JQuery)</p>
            </div>
          </div>

          <div class="col-md-4 col-sm-6 portfolio-item" data-aos="zoom-in-down">
            <a class="portfolio-link" data-toggle="modal" href="#portfolioModal4">
              <div class="portfolio-hover">
                <div class="portfolio-hover-content">
                  <i class="fas fa-plus fa-3x"></i>
                </div>
              </div>
              <img class="img-fluid" src="img/portfolio/indian-palace.jpg" alt="Indian Palace">
            </a>
            <div class="portfolio-caption">
              <h4>Indian Palace</h4>
              <p class="text-muted">Site vitrine (HTML5/CSS3, JS, JQuery)</p>
            </div>
          </div>          

          <div class="col-md-4 col-sm-6 portfolio-item" data-aos="zoom-in-down">
            <a class="portfolio-link" data-toggle="modal" href="#portfolioModal2">
              <div class="portfolio-hover">
                <div class="portfolio-hover-content">
                  <i class="fas fa-plus fa-3x"></i>
                </div>
              </div>
              <img class="img-fluid" src="img/portfolio/zeroWaste.jpg" alt="ZeroWaste">
            </a>
            <div class="portfolio-caption">
              <h4>ZeroWaste</h4>
              <p class="text-muted">Application mobile multi-platformes (IONIC 3)</p>
            </div>
          </div>

          <div class="col-md-4 col-sm-6 portfolio-item" data-aos="zoom-in-down">
            <a class="portfolio-link" data-toggle="modal" href="#portfolioModal3">
              <div class="portfolio-hover">
                <div class="portfolio-hover-content">
                  <i class="fas fa-plus fa-3x"></i>
                </div>
              </div>
              <img class="img-fluid" src="img/portfolio/asso.jpg" alt="SA SENIOR">
            </a>
            <div class="portfolio-caption">
              <h4>SA Senior</h4>
              <p class="text-muted">Application Web (Symfony 4)</p>
            </div>
          </div> 

          <div class="col-md-4 col-sm-6 portfolio-item" data-aos="zoom-in-up">
            <a class="portfolio-link" data-toggle="modal" href="#portfolioModal1">
              <div class="portfolio-hover">
                <div class="portfolio-hover-content">
                  <i class="fas fa-plus fa-3x"></i>
                </div>
              </div>
              <img class="img-fluid" src="img/portfolio/m&k.jpg" alt="M&K">
            </a>
            <div class="portfolio-caption">
              <h4>M&K</h4>
              <p class="text-muted">Application web (PHP7, HTML5/CSS, JS)</p>
            </div>
          </div>             

          <div class="col-md-4 col-sm-6 portfolio-item" data-aos="zoom-in-up">
            <a class="portfolio-link" data-toggle="modal" href="#portfolioModal5">
              <div class="portfolio-hover">
                <div class="portfolio-hover-content">
                  <i class="fas fa-plus fa-3x"></i>
                </div>
              </div>
              <img class="img-fluid" src="img/portfolio/vsa.jpg" alt="Simplification de données clients">
            </a>
            <div class="portfolio-caption">
              <h4>Simplification de données</h4>
              <p class="text-muted">Application Web (ASP.NET)</p>
            </div>
          </div>
          
        </div>
      </div>
    </section>
    <!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<!-- Portfolio Modals -->
    <!-- Modal 6 -->
    <div class=" modal fade" id="portfolioModalCM" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-12 mx-auto">
                <div class="modal-body">
                  <!-- Project Details Go Here -->
                  <h2 class="text-uppercase">Cécile Mathias - Des mots pour voir</h2>
                  <p class="item-intro text-muted">Site vitrine / Portfolio</p>
                  <a href="https://cecilemathias.fr/"><img class="img-fluid d-block mx-auto" src="img/portfolio/des-mots-pour-voir.jpg" alt="Cécile Mathias - Audiodescriptrice"></a>
                  <br><hr>
                  <p>Portfolio responsive :<br>
                  Cécile Mathias - Audiodescriptrice / Biographe indépendante.<br>
                  Développé avec :<br> HTML5/CSS3, Bootstrap, PHP, JavaScript, Jquery, Ajax.</p>
                  <hr>
                  <ul class="list-inline">
                    <li>Date: Novembre 2019</li>
                    <li>Categorie: Site vitrine / Portfolio</li>
                  </ul>
                  <button class="btn btn-primary mx-auto d-block" data-dismiss="modal" type="button">
                    <i class="fas fa-times"></i>
                    Retour</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal 5 -->
    <div class=" modal fade" id="portfolioModalFP" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-12 mx-auto">
                <div class="modal-body">
                  <!-- Project Details Go Here -->
                  <h2 class="text-uppercase">Flora Perre</h2>
                  <p class="item-intro text-muted">Site vitrine / Portfolio</p>
                  <a href="http://floraperre.com"><img class="img-fluid d-block mx-auto" src="img/portfolio/flora-perre.jpg" alt="Flora perre"></a>
                  <br><hr>
                  <p>Portfolio responsive :<br>
                  Flora Perre - Graphiste / Illustratrice indépendante.<br>
                  Développé avec :<br> HTML5/CSS3, Angular JS, Bootstrap, PHP, JavaScript, Jquery, Ajax.</p>
                  <hr>
                  <ul class="list-inline">
                    <li>Date: Mai 2019</li>
                    <li>Categorie: Site vitrine / Portfolio</li>
                  </ul>
                  <button class="btn btn-primary mx-auto d-block" data-dismiss="modal" type="button">
                    <i class="fas fa-times"></i>
                    Retour</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal 1 -->
    <div class="modal fade" id="portfolioModal1" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-12 mx-auto">
                <div class="modal-body">
                  <!-- Project Details Go Here -->
                  <h2 class="text-uppercase">M&K</h2>
                  <p class="item-intro text-muted">Application web.</p>
                  <img class="img-fluid d-block mx-auto" src="img/portfolio/m&k.jpg" alt="">
                  <br><hr>
                  <p>Application web de type commerciale, vente de vêtements (robes et accessoires).<br>
                  En cours de développement avec :<br> PHP7, HTML5/CSS3, JavaScript, Jquery, Ajax sur une base de donnée MySQL.
                  </p>
                  <hr>
                  <ul class="list-inline">
                    <li>Date: En cours</li>
                    <li>Client: Projet personnel</li>
                    <li>Categorie: Application web commerciale</li>
                  </ul>
                  <button class="btn btn-primary mx-auto d-block" data-dismiss="modal" type="button">
                    <i class="fas fa-times"></i>
                    Retour</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal 2 -->
    <div class=" modal fade" id="portfolioModal2" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-12 mx-auto">
                <div class="modal-body">
                  <!-- Project Details Go Here -->
                  <h2 class="text-uppercase">ZeroWaste</h2>
                  <p class="item-intro text-muted">Application mobile multi-plateformes</p>
                  <img class="img-fluid d-block mx-auto" src="img/portfolio/zeroWaste.jpg" alt="">
                  <br><hr>
                  <p>Application mobile de type commerciale, anti-gaspillage de produits bio.<br>
                  En cours de développement avec :<br> IONIC 3 sur une base de donnée MySQL.
                  </p>
                  <hr>
                  <ul class="list-inline">
                    <li>Date: En cours</li>
                    <li>Client: Markal</li>
                    <li>Categorie: Application mobile commerciale</li>
                  </ul>
                  <button class="btn btn-primary mx-auto d-block" data-dismiss="modal" type="button">
                    <i class="fas fa-times"></i>
                    Retour</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal 3 -->
    <div class=" modal fade" id="portfolioModal3" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-12 mx-auto">
                <div class="modal-body">
                  <!-- Project Details Go Here -->
                  <h2 class="text-uppercase">SA Senior</h2>
                  <p class="item-intro text-muted">Application web</p>
                  <img class="img-fluid d-block mx-auto" src="img/portfolio/asso.jpg" alt="">
                  <br><hr>
                  <p>Application web caritative qui présente des demandes d'aide à la personne.<br>
                  En cours de développement avec :<br> Symfony 4, JavaScript, JQuery sur une base de donnée MySQL.</p>
                  <hr>
                  <ul class="list-inline">
                    <li>Date: En cours</li>
                    <li>Client: Projet de fin d'étude</li>
                    <li>Categorie: Application web caritative</li>
                  </ul>
                  <button class="btn btn-primary mx-auto d-block" data-dismiss="modal" type="button">
                    <i class="fas fa-times"></i>
                    Retour</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal 5 -->
    <div class=" modal fade" id="portfolioModal4" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-12 mx-auto">
                <div class="modal-body">
                  <!-- Project Details Go Here -->
                  <h2 class="text-uppercase">Indian Palace</h2>
                  <p class="item-intro text-muted">Site vitrine</p>
                  <a href="https://indian-palace.karimbouzgarne.fr/"><img class="img-fluid d-block mx-auto" src="img/portfolio/indian-palace.jpg" alt="Indian Palace Bron"></a>
                  <br><hr>
                  <p>Site vitrine responsive pour un restaurant indien.<br>
                  Développé avec :<br> HTML5/CSS3, JavaScript, Jquery.</p>
                  <hr>
                  <ul class="list-inline">
                    <li>Date: Septembre 2018</li>
                    <li>Categorie: Site vitrine</li>
                  </ul>
                  <button class="btn btn-primary mx-auto d-block" data-dismiss="modal" type="button">
                    <i class="fas fa-times"></i>
                    Retour</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal 5 -->
    <div class=" modal fade" id="portfolioModal5" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-12 mx-auto">
                <div class="modal-body">
                  <!-- Project Details Go Here -->
                  <h2 class="text-uppercase">Simplification de données</h2>
                  <p class="item-intro text-muted">Application web</p>
                  <img class="img-fluid d-block mx-auto" src="img/portfolio/vsa.jpg" alt="">
                  <br><hr>
                  <p>Application web interne, Simplification de données clients et assistance à distance.<br>
                  Développé avec :<br> ASP.NET et C# sur une base de donnée PostgreSQL.</p>
                  <hr>
                  <ul class="list-inline">
                    <li>Date: Février 2016</li>
                    <li>Client: VSA Informatique</li>
                    <li>Categorie: Intranet</li>
                  </ul>
                  <button class="btn btn-primary mx-auto d-block" data-dismiss="modal" type="button">
                    <i class="fas fa-times"></i>
                    Retour</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

</body>
</html>    <!-- Formation -->
    <section id="formation">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center" data-aos="fade-right">
            <h2 class="section-heading text-uppercase">FORMATION</h2>
            <h3 class="section-subheading text-muted">Voici mon parcours depuis mes débuts en développement web.</h3>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12">
            <ul class="timeline">
              <li>
                <div class="timeline-image">
                  <img class="rounded-circle img-fluid" src="img/about/aries.jpg" alt="ARIES">
                </div>
                <div class="timeline-panel">
                  <div class="timeline-heading">
                    <h4>2017-2018</h4>
                    <h4 class="subheading">Licence professionnel CDW</h4>
                  </div>
                  <div class="timeline-body">
                    <p class="text-muted">Formation en alternance à l'école Aries (Licence conception et développement d'application web et mobile).</p>
                  </div>
                </div>
              </li>
              <li class="timeline-inverted">
                <div class="timeline-image">
                  <img class="rounded-circle img-fluid" src="img/about/bts.jpg" alt="BTS SIO">
                </div>
                <div class="timeline-panel">
                  <div class="timeline-heading">
                    <h4>2014-2016</h4>
                    <h4 class="subheading">BTS Services Informatiques aux Organisations</h4>
                  </div>
                  <div class="timeline-body">
                    <p class="text-muted">Formation au lycée Ella Fitzgerald en spécialité SLAM (Solution Logiciel Application Métier).</p>
                  </div>
                </div>
              </li>
              <li>
                <div class="timeline-image">
                  <img class="rounded-circle img-fluid" src="img/about/bac.jpg" alt="BAC STMG">
                </div>
                <div class="timeline-panel">
                  <div class="timeline-heading">
                    <h4>2014</h4>
                    <h4 class="subheading">BAC STMG</h4>
                  </div>
                  <div class="timeline-body">
                    <p class="text-muted">BAC STMG au lycée Ella Fitzgerald en spécialité SIG (Système de Gestion de l'Information).</p>
                  </div>
                </div>
              </li>
              <li class="timeline-inverted">
                <div class="timeline-image">
                  <img class="rounded-circle img-fluid" src="img/about/3.jpg" alt="Informatique">
                </div>
                <div class="timeline-panel">
                  <div class="timeline-heading">
                    <h4>Avant 2014</h4>
                    <h4 class="subheading">Passion pour l'informatique</h4>
                  </div>
                  <div class="timeline-body">
                    <p class="text-muted">Avant de débuter une formation dans le développement web, j'ai d'abord commencé par être passionné par la complexité de l'informatique et plus précisément dans la programmation.</p>
                  </div>
                </div>
              </li>
              <li class="timeline-inverted">
                <div class="timeline-image">
                  <h4>Début
                    <br>de mon
                    <br>Parcours!</h4>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <section class="bg-dark text-white">
      <div class="container text-center">
        <div class="col-lg-8 mx-auto text-center">
          <h2 class="mb-4" title="CV">Consultez mon Curriculum Vitae en ligne</h2>
          <div data-aos="fade-up">
            <a class="btn btn-light btn-xl sr-button" href="cv/index.html">Cliquez ici</a>
          </div>
        </div>
      </div>
    </section>

    <section id="contact" class="bg-light">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 mx-auto text-center">
            <div data-aos="fade-down">
              <h2 class="section-heading text-dark" title="Contact">Contact</h2>
              <hr class="my-4">
            </div>
            <p class="mb-5">N'hésitez pas à me contacter.</p>
          </div>
        </div>
        
        <div class="container">
          <div class="row">
            <div class="col-lg-12 col-lg-offset-2">            
              <form role="form" id="contactForm" data-toggle="validator" method="POST">
              <div class="messages"></div>

              <div class="controls" >
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="name"><i class="fas fa-size text-primary fa-user"></i> Nom et prénom <span class="text-primary">*</span></label>
                      <input id="name" type="text" name="name" class="form-control" placeholder="Nom et Prénom *" required="required">
                      <div class="help-block with-errors"></div>
                    </div>
                    <div class="form-group">
                      <label for="email"><i class="fas fa-size text-primary fa-at"></i> Email <span class="text-primary">*</span></label>
                      <input id="email" type="email" name="email" class="form-control" placeholder="Saisissez votre email *" required="required" >
                      <div class="help-block with-errors"></div><hr>
                      
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="message"><i class="fas fa-size text-primary fa-comment-dots"></i> Message <span class="text-primary">*</span></label>
                      <textarea id="message" name="message" class="form-control" placeholder="Saisissez votre message *" rows="3" required="required"></textarea>
                      <div class="help-block with-errors"></div>
                    </div>
                    <div class="col-md-12 text-center"><hr>       
                    <div id="msgSubmit" class="h5 text-primary text-center hidden"></div>              
                    <input type="submit" class="btn btn-send bg-primary text-white" id="form-submit" value="Envoyer">                                       
                    <div class="clearfix text-primary"></div>
                  </div>
                  </div>
                </div>               
                <!-- <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="message">Message <span class="text-primary">*</span></label>
                      <textarea id="message" name="message" class="form-control" placeholder="Saisissez votre message *" rows="4" required="required"></textarea>
                      <div class="help-block with-errors"></div>
                    </div>
                  </div>
                  <div class="col-md-12 text-center">
                    <div id="msgSubmit" class="h5 text-primary text-center hidden"></div><hr>
                    <input type="submit" class="btn btn-send bg-primary text-white" id="form-submit" value="Envoyer">
                    
                    <div class="clearfix text-primary"></div>
                  </div>
                </div>   -->           
              </div>

              </form>
            </div>
          </div>
        </div>
        
      </div>
    </section> 
    <footer class="bg-dark font-f">
      <div class="container"> 
        <div class="col-md-12 text-center text-white">
          <p><b>Copyright @2020 | Karim Bouzgarne</b></p>      
        </div>  
      </div>
    </footer>   

    <!-- Contact form -->
    <script  type="text/javascript" src="js/jquery-1.11.2.min.js"></script>
    <script type="text/javascript" src="js/validator.min.js"></script>
    <script type="text/javascript" src="js/form-scripts.js"></script>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="vendor/scrollreveal/scrollreveal.min.js"></script>
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/typed.min.js"></script>
    <script src="js/creative.min.js"></script>
    <script src="js/typed.min.js"></script>
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
    <script src="https://threejs.org/examples/js/libs/stats.min.js"></script>
    
    <!-- Animations -->

    <script type="text/javascript" src="js/typed.js"></script>

    <script type="text/javascript" src="js/particles.js"></script>

    <script type="text/javascript" src="js/loader.js"></script>

    <script type="text/javascript" src="js/wrapper-loader.js"></script>
  </body>

</html>
